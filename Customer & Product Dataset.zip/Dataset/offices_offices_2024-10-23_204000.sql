USE db_schema;
DROP TABLE IF EXISTS offices;
CREATE TABLE offices (
  officeCode nvarchar(10) NOT NULL,
  city nvarchar(50) NOT NULL,
  phone nvarchar(50) NOT NULL,
  addressLine1 nvarchar(50) NOT NULL,
  addressLine2 nvarchar(50) DEFAULT NULL,
  state nvarchar(50) DEFAULT NULL,
  country nvarchar(50) NOT NULL,
  postalCode nvarchar(15) NOT NULL,
  territory nvarchar(10) NOT NULL
);
INSERT INTO offices(officeCode,city,phone,addressLine1,addressLine2,state,country,postalCode,territory) VALUES('1','San Francisco','+1 650 219 4782','100 Market Street','Suite 300','CA','USA','94080','NA'),('2','Boston','+1 215 837 0825','1550 Court Place','Suite 102','MA','USA','02107','NA'),('3','NYC','+1 212 555 3000','523 East 53rd Street','apt. 5A','NY','USA','10022','NA'),('4','Paris','+33 14 723 4404','43 Rue Jouffroy D''abbans',null,null,'France','75017','EMEA'),('5','Tokyo','+81 33 224 5000','4-1 Kioicho',null,'Chiyoda-Ku','Japan','102-8578','Japan'),('6','Sydney','+61 2 9264 2451','5-11 Wentworth Avenue','Floor #2',null,'Australia','NSW 2010','APAC'),('7','London','+44 20 7877 2041','25 Old Broad Street','Level 7',null,'UK','EC2N 1HN','EMEA');